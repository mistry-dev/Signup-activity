package com.example.signup;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    DBHelper dbHelper;
    Button signup;
    TextView textView;
    EditText edit_username,edit_email,edit_password,edit_confirmpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper=new DBHelper(this);

         edit_username=(EditText) findViewById(R.id.e_username);
         edit_email=(EditText)findViewById(R.id.e_email);
        edit_password=(EditText)findViewById(R.id.e_password);
        edit_confirmpassword=(EditText)findViewById(R.id.e_confirmpassword);
        signup=(Button) findViewById(R.id.signupbtn);
        textView= (TextView) findViewById(R.id.textview);

        textView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String username = edit_username.getText().toString();
                String email = edit_email.getText().toString();
                String password = edit_password.getText().toString();
                String confirmpassword = edit_confirmpassword.getText().toString();

                if (username.equals("") || email.equals("") || password.equals("") || confirmpassword.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Fields is empty", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(password.equals(confirmpassword))
                    {
                        Boolean checkuser = dbHelper.checkusername(username);
                        if (checkuser == false) {
                            Boolean insert= dbHelper.Insert(username,email,password);
                            if (insert == true){
                                Toast.makeText(getApplicationContext(),"Register successfully",Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                                startActivity(intent);
                            }
                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"password is not matching",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}