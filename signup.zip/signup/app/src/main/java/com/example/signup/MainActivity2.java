package com.example.signup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
public  class MainActivity2 extends AppCompatActivity
{
    EditText editText_username,editText_password;
    Button signin;
    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        dbHelper = new DBHelper(this);
        editText_username = (EditText) findViewById(R.id.edit_username);
        editText_password = (EditText) findViewById(R.id.edit_password);
        signin = (Button) findViewById(R.id.signinbtn);

        signin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String username = editText_username.getText().toString();
                String password = editText_password.getText().toString();
                if (username.equals("") || password.equals(""))
                {
                    Toast.makeText(MainActivity2.this, "Field required", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Boolean checkuserpass = dbHelper.checkuernamepassword(username,password);
                    if (checkuserpass == true)
                    {
                        Intent intent = new Intent(MainActivity2.this,MainActivity3.class);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Invalid username and password",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}